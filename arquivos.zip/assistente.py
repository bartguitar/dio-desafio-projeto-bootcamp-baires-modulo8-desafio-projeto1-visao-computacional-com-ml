from gtts import gTTS
from IPython.display import Audio, display
import os
import time
import whisper
import webbrowser
import playsound
from pydub import AudioSegment
from IPython.display import display, HTML

# --- Módulo 1: TTS para Colab funcionando ---

def speak_TTS(text, lang='pt', filename="voice.mp3"):
    """
    Converte texto em fala e reproduz o áudio no Colab.
    """
    tts = gTTS(text=text, lang=lang)

    # Remove arquivo antigo se existir
    try:
        os.remove(filename)
    except OSError:
        pass

    # Salva o áudio
    tts.save(filename)

    # Reproduz no Colab
    display(Audio(filename, autoplay=True))

    # Espera um pouco para garantir que o áudio carregue
    time.sleep(3)

speak_TTS("Olá, eu sou seu assistente virtual!")

time.sleep(6)

speak_TTS("Como posso te ajudar hoje?")

time.sleep(3)

# --- Módulo 2: Speech to Text usando Whisper ---

# Carrega o modelo (pode ser 'tiny', 'base', 'small', 'medium', 'large')
modelo = whisper.load_model("small")

def speak_SST(arquivo_wav: str) -> str:
    """
    Converte um arquivo de áudio (.wav ou .mp3) em texto usando Whisper.
    """
    resultado = modelo.transcribe(arquivo_wav, language="pt")
    texto = resultado["text"].strip()
    print(f"🎙️ Arquivo: {arquivo_wav}")
    print(f"➡️ Texto reconhecido: {texto}")
    return texto.lower()

texto_google = speak_SST("/content/audios/abrir google.mp3")
texto_youtube = speak_SST("/content/audios/abrir youtube.mp3")

# --- Módulo 3: Executar comandos automaticamente de todos os MP3 da pasta ---
import os
import webbrowser
from gtts import gTTS
from IPython.display import Audio, display # Import Audio and display
from pydub import AudioSegment
import whisper

# Função para falar
def speak(text):
    filename = "voice.mp3"
    try:
        os.remove(filename)
    except OSError:
        pass
    tts = gTTS(text=text, lang='pt')
    tts.save(filename)
    # Use IPython.display.Audio instead of playsound
    display(Audio(filename, autoplay=True))
    # Add a small delay to allow audio to play
    import time
    time.sleep(3)


# Converter MP3 para WAV
def convert_mp3_to_wav(mp3_file):
    wav_file = mp3_file.replace(".mp3", ".wav")
    sound = AudioSegment.from_mp3(mp3_file)
    sound.export(wav_file, format="wav")
    return wav_file

# STT com Whisper
def speech_to_text(audio_file, model):
    if audio_file.endswith(".mp3"):
        audio_file = convert_mp3_to_wav(audio_file)
    result = model.transcribe(audio_file, language="pt")
    texto = result["text"].strip().lower()
    print(f"🎤 Reconhecido: {texto}")
    return texto

# Executar comando
def executar_comando_por_voz(audio_file, model):
    comando = speech_to_text(audio_file, model)

    if "google" in comando:
        speak("Abrindo o Google")
        print("🔎 Abrindo Google...")
        webbrowser.open("https://www.google.com")

    elif "youtube" in comando:
        speak("Abrindo o YouTube")
        print("📺 Abrindo YouTube...")
        webbrowser.open("https://www.youtube.com")

    else:
        speak("Desculpe, não entendi o comando.")
        print("❌ Comando não reconhecido.")

# --- Executar todos os MP3 da pasta 'audios/' ---
pasta_audios = "/content/audios/"
model = whisper.load_model("small")

for arquivo in os.listdir(pasta_audios):
    if arquivo.endswith(".mp3"):
        caminho_completo = os.path.join(pasta_audios, arquivo)
        print(f"\n▶ Processando arquivo: {arquivo}")
        executar_comando_por_voz(caminho_completo, model)
